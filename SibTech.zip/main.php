<?php

require "crest.php";

$contactList = [];
$dealList = [];
$categoryList = [];
$itemList = [];
$pointsSum = 0;
for ($i = 0; $i < PHP_INT_MAX; $i++) {
	$cmd = [
		"contactList" => [
			"method" => "crm.contact.list",
			"params" => ["filter[!=COMMENTS]" => "", "start" => $i * 50]
		],
		"dealList" => [
			"method" => "crm.deal.list",
			"params" => ["filter[CONTACT_ID]" => "", "start" => $i * 50]
		],
		"categoryList" => [
			"method" => "crm.category.list",
			"params" => ["entityTypeId" => 1038]
		],
		"itemList" => [
			"method" => "crm.item.list",
			"params" => ["filter[!=ufCrm5_1734072847]" => "", "entityTypeId" => 1038, "start" => $i * 50]
		],
	];
	$iteration = CRest::callBatch($cmd);
	foreach ($iteration["result"]["result_total"] as $method => $countValues) {
		if (count($$method) < $countValues) {
			if (!isset($iteration["result"]["result"][$method][0])) {
				foreach ($iteration["result"]["result"][$method] as $value) {
					$$method = array_merge($$method, $value);
				}
			} else $$method = array_merge($$method, $iteration["result"]["result"][$method]);
		} else unset($cmd[$method]);
	}
	if ($cmd == []) break;
}
file_put_contents(
	"allContactsAndDeals.json",
	json_encode(
		["contacts" => $contactList, "deals" => $dealList],
		JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
	)
);
foreach ($categoryList as $category) {
	$dealList["countByCategory"] = count(
		CRest::call(
			"crm.deal.list",
			["filter[CATEGORY_ID]" => $category['id']]
		)["result"]
	);
}
foreach ($itemList as $item) {
	$pointsSum += $item["ufCrm5_1734072847"];
}
print_r([
	"contacts_with_comments" => count($contactList),
	"deals_with_contacts" => count($dealList) - 1,
	"deals_by_category" => $dealList["countByCategory"],
	"points_sum" => $pointsSum,
]);