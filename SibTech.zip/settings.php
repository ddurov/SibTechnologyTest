<?php
const C_REST_WEB_HOOK_URL = 'https://b24-jr3k5i.bitrix24.ru/rest/1/m8plllckhgjsn4w0/';
const C_REST_CURRENT_ENCODING = 'UTF-8';
const C_REST_BLOCK_LOG = true;